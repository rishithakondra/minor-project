# Habibi
It is provide to information about tourism place, Hotel and Restaurant of India. basically this is static responsive site and making for learning of HTML, CSS, JavaScript and Media query.
